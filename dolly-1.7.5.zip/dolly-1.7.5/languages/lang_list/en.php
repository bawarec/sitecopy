<?php
return (object)[

];
?>