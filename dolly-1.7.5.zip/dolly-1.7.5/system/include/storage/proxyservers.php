<?php
return array (
  'meta' => 
  array (
    'host' => 
    array (
      'type' => 'string',
      'length' => 64,
      'value' => '',
    ),
    'port' => 
    array (
      'type' => 'int,null',
      'length' => 11,
    ),
    'user' => 
    array (
      'type' => 'string',
      'length' => 64,
      'value' => '',
    ),
    'password' => 
    array (
      'type' => 'string',
      'length' => 64,
      'value' => '',
    ),
    'type' => 
    array (
      'type' => 'int',
      'length' => 11,
      'value' => 0,
    ),
    'tunnel' => 
    array (
      'type' => 'bool',
      'value' => false,
    ),
  ),
  'data' => 
  array (
  ),
  'keys' => 
  array (
  ),
);
?>