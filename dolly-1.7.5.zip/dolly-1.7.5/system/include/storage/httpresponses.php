<?php
return array (
  'meta' => 
  array (
    'content_type' => 
    array (
      'type' => 'string',
      'value' => '',
    ),
    'cacheable' => 
    array (
      'type' => 'bool',
      'value' => true,
    ),
  ),
  'data' => 
  array (
    'api/lastTransactions/index' => 
    array (
      'content_type' => 'application/json',
      'cacheable' => NULL,
    ),
    'js/jquery-plugins.js' => 
    array (
      'content_type' => 'application/x-javascript',
      'cacheable' => NULL,
    ),
    'css/jquery.fancybox.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'css/custom-styles2.min.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'css/bootstrap.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'css/style.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'css/bootstrap-theme.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'js/custom-functions2.min.js' => 
    array (
      'content_type' => 'application/x-javascript',
      'cacheable' => NULL,
    ),
    'js/f20c2227859c3112d1febc7caae80d8a.js' => 
    array (
      'content_type' => 'application/x-javascript',
      'cacheable' => NULL,
    ),
    'js/bootstrap.js' => 
    array (
      'content_type' => 'application/x-javascript',
      'cacheable' => NULL,
    ),
    'js/jquery.fancybox.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/myjs.js' => 
    array (
      'content_type' => 'application/x-javascript',
      'cacheable' => NULL,
    ),
    'js/sisyphus.min.js' => 
    array (
      'content_type' => 'application/x-javascript',
      'cacheable' => NULL,
    ),
    'js/form.custom.js' => 
    array (
      'content_type' => 'application/x-javascript',
      'cacheable' => NULL,
    ),
    'fonts/HELVETICANEUECYR_BOLD.OTF' => 
    array (
      'content_type' => 'application/vnd.oasis.opendocument.formula-template',
      'cacheable' => NULL,
    ),
    'fonts/HELVETICANEUECYR-LIGHT_0.OTF' => 
    array (
      'content_type' => 'application/vnd.oasis.opendocument.formula-template',
      'cacheable' => NULL,
    ),
    'fonts/HELVETICANEUECYR-ROMAN.OTF' => 
    array (
      'content_type' => 'application/vnd.oasis.opendocument.formula-template',
      'cacheable' => NULL,
    ),
    'img/button.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/four_ic.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/link_1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/link_2.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/link_3.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/logo-2.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/slide1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/back.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => NULL,
    ),
    'img/roze7.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/roze8.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/roze9.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/roze10.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/roze11.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/roze12.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/roze13.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/roze14.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/roze15.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/roze16-ru.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/roze17-ru.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/roze18-ru.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/roze19-ru.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/roze20-ru.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/roze21-ru.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/roze22-ru.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/roze23-ru.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/roze24-ru.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/16.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/12.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/11.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/13.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/14.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/15.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/close.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/back_six.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/w5bg.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'css/login.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'img/logo.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/favicon.ico' => 
    array (
      'content_type' => 'image/vnd.microsoft.icon',
      'cacheable' => NULL,
    ),
    'css/testimonials.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'css/news.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'js/fancybox/jquery.fancybox-1.3.4.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'js/fancybox/jquery.fancybox-1.3.4.pack.js' => 
    array (
      'content_type' => 'application/x-javascript',
      'cacheable' => NULL,
    ),
    'js/jquery.cycle.all.min.js' => 
    array (
      'content_type' => 'application/x-javascript',
      'cacheable' => NULL,
    ),
    'img/book.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/logo.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => NULL,
    ),
    'testimonials_image/image_13.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/vk_icon.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'testimonials_image/image_12.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'testimonials_image/image_10.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'testimonials_image/image_9.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'testimonials_image/image_8.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/free.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/bg.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'img/email.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/index.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/bg_menu.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/shadow_menu.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/order_seo.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/callback.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'testimonials_image/image_7.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'testimonials_image/image_5.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'testimonials_image/image_4.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w110/h110/news_image/image_10.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w110/h110/news_image/image_9.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w110/h110/news_image/image_8.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/order_turbo.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/sh.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'fc/w190/h140/image/image_18.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w190/h140/image/image_17.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w190/h140/image/image_16.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w190/h140/image/image_19.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w190/h140/image/image_15.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w190/h140/image/image_12.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w190/h140/image/image_7.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w190/h140/image/image_11.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w190/h140/image/image_10.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w190/h140/image/image_9.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fctop/w190/h140/image/image_5.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w190/h140/image/image_8.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w190/h140/image/image_6.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w190/h140/image/image_3.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w190/h140/image/image_4.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/turbo.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'css/contacts.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'css/faq.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'img/opport.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'favicon.ico' => 
    array (
      'content_type' => 'image/vnd.microsoft.icon',
      'cacheable' => true,
    ),
    'css/clients.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_346.png' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_211.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_324.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_344.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_180.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_329.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_310.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/clients.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_222.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_270.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_271.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_177.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_209.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_334.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_299.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_335.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_307.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_314.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_313.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_321.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_306.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_305.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_304.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_300.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_294.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_274.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_265.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_216.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_208.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_207.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_204.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_203.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_202.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_186.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_182.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_157.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_153.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_140.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_133.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_104.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_73.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_89.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_105.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_45.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_40.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_14.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_375.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_373.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_371.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_370.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_366.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_359.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_358.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_351.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_350.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_348.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_345.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_343.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_342.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_340.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_337.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_332.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_297.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_296.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_295.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_289.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_287.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_284.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_280.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_278.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_259.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_257.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_250.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_221.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_201.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_200.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_199.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_198.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_190.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_189.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_185.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_184.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_183.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_176.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_174.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_167.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_162.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_159.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_156.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_152.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_150.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_146.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_137.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_134.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_129.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_115.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_103.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_57.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_102.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_119.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_80.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_42.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_35.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_369.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_361.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_360.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_356.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_290.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_288.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_282.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_249.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_240.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_173.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_155.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_151.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_144.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_126.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_116.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_109.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_118.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_86.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_72.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_20.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_11.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_355.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_353.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_272.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_164.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_71.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_66.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_4.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_376.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_365.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_364.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_363.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_322.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_317.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_309.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_158.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_84.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_318.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_235.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_195.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_302.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_228.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_362.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_357.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_328.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_50.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_36.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_326.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_374.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_316.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_372.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_331.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_330.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_315.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_352.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_333.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_319.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_16.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_56.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_169.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_70.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_267.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_327.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_293.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_236.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_320.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_24.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => NULL,
    ),
    'f/w99/h99/clients_image/image_367.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'assets/56df5d2d/yii.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'images/logo.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'js/jquery.placeholder.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'assets/f00c4ccd/jquery.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/jcf.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/jcf.select.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/jquery.fancybox.pack.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'images/icons.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'images/pattern.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'js/jquery.mousewheel.pack.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/func.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'assets/56df5d2d/yii.validation.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'assets/56df5d2d/yii.activeForm.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'css/mobile.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    '/robots.txt' => 
    array (
      'content_type' => 'text/plain',
      'cacheable' => true,
    ),
    'img/viber-icon.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'css/main.min.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'img/logo-property.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/vk-icon.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/whatapp-icon.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'js/scripts.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'img/remont_televizorov.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/warranty-icon.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'fonts/UbuntuRegular/UbuntuRegular.woff' => 
    array (
      'content_type' => 'application/font-woff',
      'cacheable' => NULL,
    ),
    'fonts/UbuntuBold/UbuntuBold.woff' => 
    array (
      'content_type' => 'application/font-woff',
      'cacheable' => NULL,
    ),
    'img/master.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/map-icon.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/tv-icon.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/home-icon.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/refrigerator-icon.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/parts-icon.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/washing_mach.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/clock-icon.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/computer-icon.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/header-bg-gl.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/men-image-fon.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/men-image.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/remont_holodilnikov.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/remont_stiralnih_mashin.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/remont_kompyuterov.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'favicons/favicon-32x32.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'favicons/favicon-16x16.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'favicons/android-chrome-192x192.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'favicons/favicon.ico' => 
    array (
      'content_type' => 'image/x-icon',
      'cacheable' => NULL,
    ),
    'img/master-refrigirator2.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/24hour.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/price-icon.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/discount.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/people.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/without-interme.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/woman-refri-tv.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/qaranty-label.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/woman-tv.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/partners/samsung.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/partners/lg.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/partners/toshiba.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/partners/philips.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/partners/panasonic.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/partners/sony.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/partners/supra.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/partners/pioneer.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/partners/aeg.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/partners/bbk.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/partners/sharp.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/partners/jvc.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/partners/rolsen.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/partners/thomson.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/partners/mystery.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/partners/acer.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/partners/benq.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/partners/dell.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/header-bg-tv.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/form-bg.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/red-price-board.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/breadcrumb2.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'fonts/UbuntuRegular/UbuntuRegular.eot' => 
    array (
      'content_type' => 'application/vnd.ms-fontobject',
      'cacheable' => NULL,
    ),
    'fonts/UbuntuBold/UbuntuBold.eot' => 
    array (
      'content_type' => 'application/vnd.ms-fontobject',
      'cacheable' => NULL,
    ),
    'css/font-awesome.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'css/overwrite.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'css/bootstrap.min.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'css/prettyPhoto.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'css/font-awesome-set.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'css/flexslider.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'skin/default.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'js/jquery.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/bootstrap.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/jquery-easing-1.3.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/navigation/waypoints.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/navigation/jquery.smooth-scroll.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/navigation/navbar.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'font/fontawesome-webfont.woff_m_v=3.2.1' => 
    array (
      'content_type' => 'application/font-woff',
      'cacheable' => NULL,
    ),
    'img/home-bg.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'js/cbpscroller/modernizr.custom.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/cbpscroller/classie.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/cbpscroller/cbpScroller.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/jcarousellite/jcarousellite_1.0.1c4.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/jcarousellite/setting.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/ticker/ticker.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/ticker/setting.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/prettyPhoto/jquery.prettyPhoto.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/prettyPhoto/setting.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/filter/jquery.quicksand.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/filter/setting.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/flexslider/jquery.flexslider.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/flexslider/setting.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/validation.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/totop/jquery.ui.totop.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/totop/setting.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/custom.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'img/features/img3.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/features/bg.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/features/bg1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/features/img2.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/features/bg2.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/features/img4.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/features/bg3.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/gallery/1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/gallery/2.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/gallery/3.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/gallery/4.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/gallery/5.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/gallery/6.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/gallery/7.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/gallery/8.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/gallery/9.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'img/heading-bg.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/vertical-line.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/circle.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/work-it-icon-line.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/headline-arrow.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/bg_direction_nav_prev.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/bg_direction_nav_next.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/ui.totop.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'ico/favicon.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'font/fontawesome-webfont.eot' => 
    array (
      'content_type' => 'application/vnd.ms-fontobject',
      'cacheable' => NULL,
    ),
    'content/cache/autoptimize/css/autoptimize_72a6a749f991ec256ad562f5a7910018.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'content/uploads/DS-1.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => NULL,
    ),
    'content/uploads/shah-ban-1.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => NULL,
    ),
    'content/uploads/ASOT-2.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'content/uploads/benedict22.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'content/plugins/weekly_table2_film2movie/icons.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'content/uploads/Asheghaneh1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'content/uploads/Gun-Shy-2017.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'content/uploads/imdb.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'content/uploads/The_Mummy_2017.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'content/uploads/The-Ghoul-2017.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'content/uploads/Death-Note-2017.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'content/uploads/TV.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'content/uploads/The-Limehouse-Golem-2016.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'content/uploads/Thor_Ragnarok.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'content/uploads/The-Battleship-Island-2017.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'content/themes/film2movie/images/tele.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'content/cache/autoptimize/js/autoptimize_bde39d7beaadb17e5acc2d536a00e066.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'content/themes/film2movie/images/favicon.ico' => 
    array (
      'content_type' => 'image/x-icon',
      'cacheable' => NULL,
    ),
    'image/plugins/icons/image_8.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'image/plugins/b_side/image_8.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'image/plugins/b_side/image_7.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'image/plugins/b_side/image_1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'image/plugins/icons/image_6.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'image/plugins/icons/image_7.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'image/plugins/icons/image_17.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'image/plugins/icons/image_18.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'image/plugins/icons/image_16.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'main_a_mdl__form_a_pl_banners.7811eaac.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'img/bg2.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'msfieldset.4570c7ac.js' => 
    array (
      'content_type' => 'text/javascript',
      'cacheable' => NULL,
    ),
    'css/font.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'css/font-awesome.min.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'css/custom-checkbox.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'css/owl.carousel.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'css/eagle.gallery.min.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'js/SmoothScroll.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/fastCart.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'img/buy-arrow.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'img/delivery-img.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'js/owl.carousel.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/eagle.gallery.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'js/workscripts.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'fonts/font-awesome/fontawesome-webfont.woff_m_v=4.7.0' => 
    array (
      'content_type' => 'application/font-woff',
      'cacheable' => NULL,
    ),
    '_js/jquery-1.11.1.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'bitrix/cache/css/SC/new_school/kernel_main/kernel_main.css_m_15046015449387.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    '_js/ita_marketing.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'bitrix/cache/css/SC/new_school/template_c0c406d6a7593e4ac24a876185e28c6c/template_c0c406d6a7593e4ac24a876185e28c6c_289e5eda17b9ce3da6cf8a037fddfedf.css_m_1505399667184574.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    '_js/jquery.bxslider.min.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    '_js/sourcebuster.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'bitrix/cache/js/SC/new_school/kernel_main/kernel_main.js_m_1504601544240204.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    '_js/jquery.maskedinput.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    '_js/jquery.placeholder.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    '_js/jquery.formstyler.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    '_js/jquery.validate.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    '_js/jquery.jcarousel.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    '_js/iLoad/iLoad.js_m_1503660869.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'bitrix/templates/school_inner/images/icons/noun.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'bitrix/templates/new_school/images/logo.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'upload/iblock/e55/e550251526a123e32e76a39256168d2c.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'upload/iblock/cc8/cc8e663577af370fcbf3451a47f36fc6.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    '_js/jquery.bxslider.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    '_js/css_change.js_m_1478102491.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    '_js/tabs.js_m_1478102491.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    '_js/main.js_m_1505400803.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    '_js/google_yandex_goals.js_m_1501086293.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    '_js/required_filds_form.js_m_1478102491.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    '_js/jquery.jcarousel.js_m_1478102491.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    '_js/arrows_position.js_m_1478102491.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    '_js/LiveTex.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'bitrix/templates/new_school/images/logo_small.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'upload/iblock/4b0/4b09e79a7a2c175021614adbd94e3a43.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    '_js/skins/tango/prev-horizontal.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    '_js/skins/tango/next-horizontal.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'general-english/css/style.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'general-english/js/picturefill.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'general-english/js/jquery-3.1.1.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'general-english/js/owl.carousel.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'general-english/source/jquery.fancybox.css_m_v=2.0.6.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'general-english/js/slick.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    '_js/sb-placer.jquery.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'general-english/source/jquery.fancybox.js_m_v=2.0.6.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'general-english/js/script.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'general-english/js/jquery.fancybox.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'general-english/images/logo-metro@1x.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'general-english/js/form-action.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => NULL,
    ),
    'general-english/images/iq-consultancy-logo@1x.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'general-english/images/icon-phone@1x.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'general-english/fonts/HelveticaNeueCyr-Medium.otf' => 
    array (
      'content_type' => 'application/octet-stream',
      'cacheable' => NULL,
    ),
    'general-english/fonts/HelveticaNeueCyr-Bold.otf' => 
    array (
      'content_type' => 'application/octet-stream',
      'cacheable' => NULL,
    ),
    'general-english/fonts/HelveticaNeueCyr-Thin.otf' => 
    array (
      'content_type' => 'application/octet-stream',
      'cacheable' => NULL,
    ),
    'general-english/fonts/HelveticaNeueCyr-Light.otf' => 
    array (
      'content_type' => 'application/octet-stream',
      'cacheable' => NULL,
    ),
    'general-english/images/hourglass@1x.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'general-english/images/calendar@1x.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'general-english/images/people@1x.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'general-english/images/timer@1x.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    '_js/phones.json' => 
    array (
      'content_type' => 'application/json',
      'cacheable' => NULL,
    ),
    'general-english/images/am@1x.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'general-english/images/pm@1x.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'general-english/images/weekend@1x.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'general-english/images/free__icon@1x.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'general-english/images/gleb.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'general-english/images/evgeniya.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'general-english/images/kirill.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'general-english/images/natalia.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'general-english/images/nelli.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'general-english/images/ekaterina.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'general-english/images/julia.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'general-english/images/anton.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'general-english/images/n.shakhmatova.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'general-english/images/ajax-loader.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => NULL,
    ),
    '404/style.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    '404/images/Background.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    '404/images/IQ_logo_Yz_2.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'general-english/images/hero__bg.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'assets/e4b3e02d/bootstrap/css/bootstrap.min.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'assets/e4b3e02d/font-awesome/css/font-awesome.min.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'assets/e4b3e02d/css/bootstrap-yii.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'assets/e4b3e02d/css/jquery-ui-bootstrap.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/css/main.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/css/flags.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/css/yupe.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/css/index.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'assets/8c2b1be1/listview/styles.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'assets/e94fbee9/pager.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    'assets/78b38ab5/jquery.min.js' => 
    array (
      'content_type' => 'application/x-javascript',
      'cacheable' => NULL,
    ),
    'assets/e4b3e02d/bootstrap/js/bootstrap.min.js' => 
    array (
      'content_type' => 'application/x-javascript',
      'cacheable' => NULL,
    ),
    'assets/e4b3e02d/js/bootstrap-noconflict.js' => 
    array (
      'content_type' => 'application/x-javascript',
      'cacheable' => NULL,
    ),
    'assets/e4b3e02d/bootbox/bootbox.min.js' => 
    array (
      'content_type' => 'application/x-javascript',
      'cacheable' => NULL,
    ),
    'assets/e4b3e02d/notify/notify.min.js' => 
    array (
      'content_type' => 'application/x-javascript',
      'cacheable' => NULL,
    ),
    'assets/78b38ab5/jquery.yiiactiveform.js' => 
    array (
      'content_type' => 'application/x-javascript',
      'cacheable' => NULL,
    ),
    'assets/78b38ab5/jquery.ba-bbq.min.js' => 
    array (
      'content_type' => 'application/x-javascript',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/js/bootstrap-notify.js' => 
    array (
      'content_type' => 'application/x-javascript',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/js/jquery.li-translit.js' => 
    array (
      'content_type' => 'application/x-javascript',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/js/analytics.js' => 
    array (
      'content_type' => 'application/x-javascript',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/js/requests.js_m_v=0.2.js' => 
    array (
      'content_type' => 'application/x-javascript',
      'cacheable' => NULL,
    ),
    'assets/8c2b1be1/listview/jquery.yiilistview.js' => 
    array (
      'content_type' => 'application/x-javascript',
      'cacheable' => NULL,
    ),
    'uploads/thumbs/currency/24x24_a0ad1a599a6986154bed9810533c58a4.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'uploads/thumbs/currency/24x24_97cde5463cf8c094b31cbdb67dee2124.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'uploads/thumbs/currency/24x24_db9ae69d5f2ea0d70ed0edd03b894bb8.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'uploads/thumbs/currency/24x24_cd0be77af2fdecfb5490b669a7ecfa57.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'uploads/thumbs/currency/24x24_a5cf80c3eef93772edfb14505b9d6241.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/fonts/LatoBold.ttf' => 
    array (
      'content_type' => 'application/octet-stream',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/fonts/LatoRegular.ttf' => 
    array (
      'content_type' => 'application/octet-stream',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/fonts/LatoLight.ttf' => 
    array (
      'content_type' => 'application/octet-stream',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/images/main/logo.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/images/main/header.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/images/content/step1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/images/content/give.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/images/content/get.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/images/content/data.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/images/content/but.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/images/content/arrow-ask.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/images/main/cross.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/images/content/shape.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'uploads/thumbs/currency/24x24_7888088e4bbd8ef3cf9c805829002d87.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/images/content/arrow-oh.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/images/footer/res.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/images/footer/mon.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/images/content/tw.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/images/content/vk.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/images/favicon.ico' => 
    array (
      'content_type' => 'image/x-icon',
      'cacheable' => NULL,
    ),
    'assets/8e2bbe6/images/content/but-hover.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => NULL,
    ),
    '57a1300ab2351ff4fcc6a94d07419280/bWFpbnxob21lfGpxdWVyeS5mbGlwY291bnRkb3du.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => NULL,
    ),
    '9eb6fb216f13bcc6f044c2baab2fa279/anF1ZXJ5LmZsaXBjb3VudGRvd258bWRsX2RlYWRsaW5lX3Bnc3xqcXVlcnkuY3ljbGUyLm1pbnxqcXVlcnkuY3ljbGUyLnNjcm9sbFZlcnQubWlu.js' => 
    array (
      'content_type' => 'text/javascript',
      'cacheable' => NULL,
    ),
    'image/slider/5293.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'image/slider/5352.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'image/slider/5364.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'image/slider/5358.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'image/slider/5367.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w100/h100/image/5285.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w100/h100/image/5333.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w100/h100/image/5299.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w100/h100/image/5361.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w100/h100/image/5360.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w100/h100/image/5293.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w100/h100/image/5358.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w100/h100/image/5411.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w100/h100/image/5296.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w100/h100/image/5401.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w100/h100/image/5309.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w100/h100/image/5318.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w100/h100/image/5379.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'fc/w100/h100/image/5335.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'fc/w100/h100/image/5367.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w100/h100/image/5377.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w100/h100/image/5331.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w100/h100/image/5364.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w100/h100/image/5308.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w100/h100/image/5289.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w100/h100/image/5382.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w100/h100/image/5385.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w100/h100/image/5392.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w100/h100/image/5301.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => NULL,
    ),
    'fc/w100/h100/image/5389.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'fc/w100/h100/image/5325.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'fc/w100/h100/image/5352.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'img/neoflat.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'img/progbar.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    '60571ee7330a3be345fe54e0da290817/bWFpbnxmZWVkYmFjaw_a__a_.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'main_a_mdl__form_a_pl_banners.24257003.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'pl_join_a_msfieldset.00d14eb9.js' => 
    array (
      'content_type' => 'text/javascript',
      'cacheable' => true,
    ),
    'o__msapis.com/js/ms.scroll_top-1.0.js' => 
    array (
      'content_type' => 'application/x-javascript',
      'cacheable' => true,
    ),
    'media/j2store/css/bootstrap.min.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'media/j2store/css/font-awesome.min.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'media/j2store/css/jquery-ui-custom.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'media/jui/css/bootstrap.min.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'templates/sparky_framework/css/sparky-id98-170829170742.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'modules/mod_j2store_cart/css/j2store_cart.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'templates/sparky_framework/css/normalize.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'modules/mod_hot_swipe_carousel/tmpl/style.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'templates/sparky_framework/css/icons/font-awesome.min.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'media/jui/js/jquery-noconflict.js_m_4820b664529cff55ffdb703342cfa9ea.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'media/j2store/css/j2store.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'media/jui/js/jquery.min.js_m_4820b664529cff55ffdb703342cfa9ea.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'media/j2store/js/jquery-ui-timepicker-addon.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'media/jui/js/bootstrap.min.js_m_4820b664529cff55ffdb703342cfa9ea.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'media/jui/js/jquery-migrate.min.js_m_4820b664529cff55ffdb703342cfa9ea.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'media/j2store/js/jquery-ui.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'media/j2store/js/j2store.namespace.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'media/j2store/js/j2store.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'media/system/js/caption.js_m_4820b664529cff55ffdb703342cfa9ea.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'media/j2store/js/jquery.zoom.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'templates/sparky_framework/js/sparky-id98-170829170742.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'modules/mod_hot_swipe_carousel/js/flickity.pkgd.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'templates/sparky_framework/js/responsive-nav.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'templates/sparky_framework/js/sparky-footer-id98-170829170742.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'images/products/featured/0004_2_2.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'images/products/featured/0624_2.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'images/products/featured/1339_2.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'images/products/featured/1315_2.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'templates/sparky_framework/images/icons/icon192x192.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'images/products/featured/0818_2.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'templates/sparky_framework/images/custom/top_row_bg.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'templates/sparky_framework/images/logo.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'images/products/featured/0820_2.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'images/products/featured/0894_2.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'images/carousel/slide1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'images/carousel/slide2.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'images/products/featured/lapa_2.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'images/products/featured/1082_2.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'images/carousel/slide3.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'images/silca_duo_plus.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'images/products/featured/0014_2.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'images/products/featured/0550_2.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'templates/sparky_framework/images/custom/advert_row_top_bg.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'templates/sparky_framework/images/custom/bottom_row_bg.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'templates/sparky_framework/images/custom/advert_row_bottom_bg.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'templates/sparky_framework/css/fonts/fontawesome-webfont.woff_m_v=4.7.0' => 
    array (
      'content_type' => 'application/font-woff',
      'cacheable' => true,
    ),
    'templates/system/css/error.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'templates/sparky_framework/js/html5shiv.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'templates/sparky_framework/js/respond.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'media/j2store/fonts/fontawesome-webfont.eot_m_v=4.2.0' => 
    array (
      'content_type' => 'application/vnd.ms-fontobject',
      'cacheable' => true,
    ),
    'templates/sparky_framework/css/fonts/fontawesome-webfont.eot_m_v=4.7.0' => 
    array (
      'content_type' => 'application/vnd.ms-fontobject',
      'cacheable' => true,
    ),
    'media/jui/js/html5.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'media/system/js/keepalive.js_m_4820b664529cff55ffdb703342cfa9ea.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'media/system/js/validate.js_m_4820b664529cff55ffdb703342cfa9ea.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'media/system/js/core.js_m_4820b664529cff55ffdb703342cfa9ea.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'media/system/js/html5fallback.js_m_4820b664529cff55ffdb703342cfa9ea.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'media/system/js/punycode.js_m_4820b664529cff55ffdb703342cfa9ea.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'media/system/js/caption.js_m_b5d9ad8473362db13f5914c2aa0f6345.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'media/jui/js/jquery.min.js_m_b5d9ad8473362db13f5914c2aa0f6345.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'media/jui/js/bootstrap.min.js_m_b5d9ad8473362db13f5914c2aa0f6345.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'media/jui/js/jquery-migrate.min.js_m_b5d9ad8473362db13f5914c2aa0f6345.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'media/jui/js/jquery-noconflict.js_m_b5d9ad8473362db13f5914c2aa0f6345.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'templates/sparky_framework/images/tinynav.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'images/products/featured/1082_1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'files/glyphicons/style-new.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'files/bootstrap/js/bootstrap.min.js' => 
    array (
      'content_type' => 'text/javascript',
      'cacheable' => true,
    ),
    'files/lightbox/js/lightbox-2.6.min.js' => 
    array (
      'content_type' => 'text/javascript',
      'cacheable' => true,
    ),
    'files/lightbox/css/lightbox.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'files/detect.js' => 
    array (
      'content_type' => 'text/javascript',
      'cacheable' => true,
    ),
    'files/bootstrap/css/bootstrap.min.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'a.php_m_p=2' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'a.php_m_p=5552' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'a.php_m_p=3838' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'a.php_m_p=5997' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'a.php_m_p=4277' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'a.php_m_p=5611' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'a.php_m_p=6034' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'a.php_m_p=3566' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'o__imgwm.com/img/5df/0e6/def8e741ac55f609040a1aa528.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'o__imgwm.com/upload/808/34a/56a884728c3b4176403cc5fad9.jpeg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'a.php_m_p=3753' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'a.php_m_p=3353' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'a.php_m_p=5987' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'a.php_m_p=5182' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'o__imgwm.com/upload/8ff/3ba/79637454e7337b01fdfd699fb0.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'a.php_m_p=3239' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'a.php_m_p=3117' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'o__imgwm.com/img/1bb/681/e902a0366c2e0b16d370f52c87.jpeg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'a.php_m_p=5818' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'a.php_m_p=4809' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'o__imgwm.com/img/38d/e35/9a6fa870152439bc75a615cf33.jpeg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'a.php_m_p=3691' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'o__imgwm.com/upload/952/415/e87a5217475211b41ec1a9f103.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'files/flags/ru.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'o__imgwm.com/upload/729/ff4/9ede3a18487d047c93591acd6e.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'files/jquery.min.js' => 
    array (
      'content_type' => 'text/javascript',
      'cacheable' => true,
    ),
    'o__imgwm.com/upload/2c3/ac3/32bebd937f6fd19c8e49d22c6f.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'o__imgwm.com/upload/158/a5b/b780769e28d862d2fb368cd8f3.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'a.php_m_p=4870' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'a.php_m_p=5128' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'files/bootstrap/fonts/glyphicons-halflings-regular.woff2' => 
    array (
      'content_type' => 'application/octet-stream',
      'cacheable' => true,
    ),
    'files/edu_revenue.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'files/emojis/387.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'files/emojis/575.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'files/lightbox/img/close.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'files/lightbox/img/loading.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'files/lightbox/img/next.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'files/lightbox/img/prev.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'parse/s.rutor.org/css.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'css/css.css_m_27046.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'css/pluso.css_m_12s3.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'zax/jquery.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'grannypatries/s.css_m_12s32.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'parse/s.rutor.org/jquery.cookie-min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'css/jquery.tablesorter.new-rutor.min.js_m_1.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'css/pluso-like-small.js_m_8.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'rutor-logo.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'parse/s.rutor.org/i/ic24.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'parse/s.rutor.org/i/d.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'parse/s.rutor.org/i/m.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'parse/s.rutor.org/i/com.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'parse/s.rutor.org/t/arrowup.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'parse/s.rutor.org/t/arrowdown.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'parse/s.rutor.org/t/functions.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'css/img/pluso/sprite.png_m_1=' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'parse/s.rutor.org/t/news_line.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'parse/s.rutor.org/i/menu_b1.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'parse/s.rutor.org/i/bbackgr.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'parse/s.rutor.org/i/forum.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'parse/s.rutor.org/i/poisk_bg.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'parse/s.rutor.org/i/lupa.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'parse/s.rutor.org/t/top.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'agrrr/img/movies_btn.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'parse/s.rutor.org/i/backgr.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'parse/s.rutor.org/i/zaiti.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'agrrr/img/sort-bg.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'files/advertisement.js' => 
    array (
      'content_type' => 'text/javascript',
      'cacheable' => true,
    ),
    'a.php_m_p=3284' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'a.php_m_p=3895' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'a.php_m_p=1043' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'themes/lange/css/main.css_m_59f4e74274135.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'lange/javascript/libs/modernizr.js' => 
    array (
      'content_type' => 'text/javascript',
      'cacheable' => true,
    ),
    'themes/images/general/logo.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'assets/StartPage-watch-animation-fallback-440-x-720px/LANGE-LANGE1-191-032-front.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'assets/ListingImages-568x360-px/_resampled/SetRatioSize140140-SetRatioSize220360-origin-1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'assets/ListingImages-568x360-px/_resampled/SetRatioSize140140-manufaktur.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'assets/_combinedfiles/lange.main.js_m_m=1508924877.js' => 
    array (
      'content_type' => 'text/javascript',
      'cacheable' => true,
    ),
    'assets/_combinedfiles/startpage.js_m_m=1508924888.js' => 
    array (
      'content_type' => 'text/javascript',
      'cacheable' => true,
    ),
    'themes/fonts/ALS-Headline.woff' => 
    array (
      'content_type' => 'text/plain',
      'cacheable' => true,
    ),
    'themes/images/icon-sdfa5ed302a.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'themes/images/general/border-vertical.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'lange/javascript/libs/swfobject.js_m_m=1449594380.js' => 
    array (
      'content_type' => 'text/javascript',
      'cacheable' => true,
    ),
    'assets/FooterTeaser/_resampled/CroppedImage500320-ALS-NEWS-neu.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'assets/MetaImages/Footer-Haendler-u-Boutiquen-c.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'assets/FooterTeaser/_resampled/CroppedImage500320-ALS-Stammhaus-S2013-Detail-03-a4.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'themes/images/general/logo-light.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'themes/images/startpage-watches/lange-1-neu/hours.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'themes/images/startpage-watches/lange-1-neu/minutes.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'themes/images/startpage-watches/lange-1-neu/clock_body.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'themes/images/startpage-watches/lange-1-neu/seconds.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'themes/images/startpage-watches/lange-1-neu/days_top.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'themes/images/startpage-watches/lange-1-neu/day2.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'themes/images/startpage-watches/lange-1-neu/day1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'themes/images/favicons/favicon.ico' => 
    array (
      'content_type' => 'image/vnd.microsoft.icon',
      'cacheable' => true,
    ),
    'themes/lange/css/main.css_m_59f4e75db5814.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'assets/_combinedfiles/families.js_m_m=1508924902.js' => 
    array (
      'content_type' => 'text/javascript',
      'cacheable' => true,
    ),
    'assets/Timepieces/FrontImage-440x720-px-FrontDetailImage-2320x3600-px/ZEITWERK-MINUTE-REPEATER-147-025-front.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'assets/Timepieces/FrontImage-440x720-px-FrontDetailImage-2320x3600-px/ALS-191-028-Front.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'assets/Timepieces/FrontImage-440x720-px-FrontDetailImage-2320x3600-px/252-032-front.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'themes/images/general/loader-s.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'themes/images/general/blind-right.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'themes/images/general/blind-left.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'assets/Timepieces/FrontImage-440x720-px-FrontDetailImage-2320x3600-px/Lange-1815-Tourbillon-Rotgold-pink-gold-235-032-front-72dpi.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'assets/Timepieces/FrontImage-440x720-px-FrontDetailImage-2320x3600-px/ALS-219-028-Front.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'en/timepieces/json/lange-1.html' => 
    array (
      'content_type' => 'application/json',
      'cacheable' => true,
    ),
    'themes/images/general/loader-light.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'themes/images/general/loader-black.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'assets/Timepieces/FrontImage-440x720-px-FrontDetailImage-2320x3600-px/_resampled/CroppedImage74122-Lange-1815-Tourbillon-Rotgold-pink-gold-235-032-front-72dpi.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'en/timepieces/json/1815.html' => 
    array (
      'content_type' => 'application/json',
      'cacheable' => true,
    ),
    'assets/Timepieces/FrontImage-440x720-px-FrontDetailImage-2320x3600-px/_resampled/CroppedImage74122-ALS-219-028-Front.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'en/timepieces/json/saxonia.html' => 
    array (
      'content_type' => 'application/json',
      'cacheable' => true,
    ),
    'assets/Timepieces/FrontImage-440x720-px-FrontDetailImage-2320x3600-px/_resampled/CroppedImage74122-ALS-191-028-Front.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'themes/lange/css/main.css_m_59f4e7a37ad58.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'assets/MetaImages/_resampled/CroppedImage960340-ALS-Stammhaus-S2013-Detail-02-a2.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'assets/MetaImages/Meta-Kontakt-Allgemein.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'assets/MetaImages/Meta-KS-Serviceanfrage-20100512-Lange-Gruppe-0803-Kopie.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'assets/MetaImages/284x180.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'wp-content/plugins/contact-form-7/includes/css/styles.css_m_ver=4.6.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/style.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'wp-content/plugins/download-monitor/assets/css/frontend.css_m_ver=4.7.6.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/includes/fancybox/jquery.fancybox-1.3.4.css_m_ver=4.7.6.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'wp-content/plugins/wp-syntax/css/wp-syntax.css_m_ver=1.1.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/fonts/style-rokkitt.css_m_ver=4.7.6.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/includes/shortcodes/includes/css/friendly_buttons.css_m_ver=4.7.6.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/css/style.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/css/settings.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'wp-includes/js/jquery/jquery.js_m_ver=1.12.4.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'wp-includes/js/jquery/jquery-migrate.min.js_m_ver=1.4.1.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/includes/js/jquery.slabtext.min.js_m_ver=4.7.6.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/includes/js/jquery.easing.1.3.js_m_ver=4.7.6.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/includes/fancybox/jquery.mousewheel-3.0.4.pack.js_m_ver=4.7.6.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/includes/fancybox/jquery.fancybox-1.3.4.pack.js_m_ver=4.7.6.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/includes/js/slides.jquery.js_m_ver=4.7.6.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/js/jquery.easing.1.3.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/js/jquery.cssAnimate.mini.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/js/jquery.touchwipe.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/js/jquery.mousewheel.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/js/jquery.themepunch.services.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'wp-content/plugins/contact-form-7/includes/js/jquery.form.min.js_m_ver=3.51.0-2014.06.20.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'wp-content/plugins/contact-form-7/includes/js/scripts.js_m_ver=4.6.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'wp-content/plugins/wp-syntax/js/wp-syntax.js_m_ver=1.1.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'wp-includes/js/wp-embed.min.js_m_ver=4.7.6.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'wp-content/uploads/2013/06/logo21.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/slideimg/BizSpark_Startup.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/images/bg_fabric.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/images/bg_sidebar_right.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/images/ribbon_menu.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/images/stars.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/slideimg/smsclogo166.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/slideimg/smsclogo73.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/slideimg/shneider.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/slideimg/gloologo.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/slideimg/scan4you.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/uploads/2013/06/i-170x120.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/uploads/2013/12/11_452_oboi_podarki_pod_elkoj_1280x1024-170x120.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/images/latest_fallback.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/uploads/2013/12/photoview.jpeg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'wp-content/uploads/2014/06/sparklogo.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/uploads/2013/11/santi-shield-blue.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/uploads/2013/11/santi-shield-red.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/images/ru.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/images/stars_wide.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/assets/button/btn_light.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/assets/button/close.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/assets/button/left.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/themes/campaign/assets/button/right.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-includes/js/comment-reply.min.js_m_ver=4.7.6.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'wp-content/uploads/2013/07/Screenshot-2015-09-02-21.04.24-2.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/uploads/2013/07/main-768x590.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/uploads/2013/07/main-1-768x477.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/uploads/2013/07/start.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/uploads/2013/07/utils-1024x798.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/uploads/2013/07/generator-1024x451.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/uploads/2013/07/ftp-1024x657.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/uploads/2013/07/backup-1024x594.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/uploads/2013/07/block-1024x451.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/uploads/2013/07/blockpage-1024x569.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/uploads/2013/07/phpinfo-1024x456.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/uploads/2013/07/news-1024x456.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/uploads/2013/07/date-1024x563.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/uploads/2013/07/feditor-1024x571.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/uploads/2013/07/clear-1024x611.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'wp-content/plugins/contact-form-7/images/ajax-loader.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    's__assets/assets/porn/img/logo/logo_1.png_m_ver=1431354042' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    's__assets/assets/porn/img/logo/logo_mobile_1.png_m_ver=1476361728' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172909/320x180/2.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/173003/320x180/8.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172916/320x180/2.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__assets/assets/porn/js/bundle.js_m_ver=1507645540.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172629/320x180/10.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172745/320x180/14.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__assets/assets/porn/css/icons_fonts.css_m_ver=1494943353.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172917/320x180/15.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172631/320x180/17.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172746/320x180/14.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172763/320x180/7.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172628/320x180/15.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172641/320x180/8.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__assets/assets/porn/fonts/pornes_icon.woff2_m_ver=20170515' => 
    array (
      'content_type' => 'application/octet-stream',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172637/320x180/9.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172626/320x180/2.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172640/320x180/10.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172639/320x180/7.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172638/320x180/3.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172627/320x180/6.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172623/320x180/13.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172606/320x180/10.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172605/320x180/20.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172621/320x180/5.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172624/320x180/4.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172622/320x180/3.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172602/320x180/19.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172604/320x180/14.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172603/320x180/20.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172625/320x180/11.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172610/320x180/8.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172612/320x180/10.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172692/320x180/17.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172611/320x180/8.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172608/320x180/4.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172609/320x180/9.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172708/320x180/4.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/172672/320x180/15.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__assets/assets/porn/img/preload_content.gif_m_ver=1440577512' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    's__assets/assets/porn/img/loading.gif_m_ver=1423844427' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    's__assets/assets/porn/img/logo/logo_1.png_m_ver=1431354043' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    's__assets/assets/porn/js/bundle.js_m_ver=1507645542.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/03/181340/320x180/7.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2014/02/49887/320x180/clips/1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2012/05/3199/320x180/clips/6.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2012/12/10626/320x180/1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2012/11/9891/320x180/15.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2012/12/10859/320x180/1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2012/11/9375/320x180/4.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2012/12/10625/320x180/4.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2012/12/10854/320x180/13.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2012/12/10933/320x180/7.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2012/12/10931/320x180/7.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2012/12/10929/320x180/7.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2012/12/10895/320x180/18.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2012/12/10893/320x180/20.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2012/12/11004/320x180/7.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2013/01/11473/320x180/17.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2013/01/11472/320x180/6.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2013/01/11457/320x180/2.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2013/01/11440/320x180/1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2013/01/11439/320x180/19.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2013/01/11438/320x180/6.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__assets/assets/porn/img/social_share/tumblr.png_m_ver=1479903406' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    's__assets/assets/porn/img/social_share/twitter.png_m_ver=1479903406' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    's__assets/assets/porn/img/social_share/reddit.png_m_ver=1479903406' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    's__assets/assets/porn/img/social_share/vk.png_m_ver=1479903406' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    's__assets/assets/default/js/excluded/tkn_char_counter.js_m_ver=1467110336.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    's__assets/assets/porn/img/social_share/stumbleupon.png_m_ver=1479903406' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/10/168165/320x180/19.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/04/186490/320x180/19.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/11/169402/320x180/clips/3.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/02/178929/320x180/clips/2.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/02/180877/320x180/20.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/03/184056/320x180/1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/03/184215/320x180/2.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/04/186809/320x180/17.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/02/177654/320x180/2.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/02/180628/320x180/clips/17.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/02/180629/320x180/14.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/03/181170/320x180/clips/19.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/03/182860/320x180/5.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/03/184050/320x180/3.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/05/188561/320x180/clips/14.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/02/178644/320x180/clips/1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/11/170626/320x180/20.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/02/178643/320x180/clips/19.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/03/181339/320x180/clips/3.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/10/167865/320x180/clips/1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/04/186757/320x180/9.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/05/188557/320x180/6.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/01/175035/320x180/clips/16.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/04/185672/320x180/clips/18.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/11/169187/320x180/clips/14.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/05/188552/320x180/9.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/02/180633/320x180/8.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/04/187182/320x180/3.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/03/184058/320x180/4.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/11/169197/320x180/clips/4.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/04/188466/320x180/11.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/02/180631/320x180/clips/10.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/03/184163/320x180/5.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/04/186486/320x180/clips/1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/04/185673/320x180/16.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/10/167071/320x180/9.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/04/188145/320x180/5.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/02/180635/320x180/3.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/02/179518/320x180/16.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/04/185671/320x180/clips/3.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/11/170315/320x180/8.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/02/180482/320x180/clips/4.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/04/187166/320x180/14.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/11/170519/320x180/3.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/11/171109/320x180/4.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/11/170612/320x180/9.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/04/186758/320x180/16.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/02/176943/320x180/4.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/04/185482/320x180/9.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/03/184043/320x180/15.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/03/182978/320x180/12.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/10/167356/320x180/clips/8.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/04/187184/320x180/4.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/03/184868/320x180/20.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/01/173921/320x180/2.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/03/184037/320x180/7.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/03/184021/320x180/7.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/11/169168/320x180/clips/17.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/05/188562/320x180/12.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/02/178566/320x180/5.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/02/179186/320x180/5.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/03/184052/320x180/17.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/03/184458/320x180/7.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/05/188745/320x180/clips/19.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/12/171875/320x180/1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/02/178839/320x180/5.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/03/184026/320x180/7.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2016/10/168652/320x180/6.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/02/178940/320x180/clips/3.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    's__videoassets/thumbs/2017/03/181166/320x180/10.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'html5player/hls_loaded/16901113/2/index' => 
    array (
      'content_type' => 'application/json',
      'cacheable' => true,
    ),
    'video-user-suggest/languages/index' => 
    array (
      'content_type' => 'application/json',
      'cacheable' => true,
    ),
    'html5player/hls_buffer_duration/16901113/2/492/index' => 
    array (
      'content_type' => 'application/json',
      'cacheable' => true,
    ),
    'favicon-32x32.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'favicon-16x16.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'html5player/hls_buffer_duration/16901113/2/211/index' => 
    array (
      'content_type' => 'application/json',
      'cacheable' => true,
    ),
    'html5player/hls_network_speed/16901113/2/1414397/index' => 
    array (
      'content_type' => 'application/json',
      'cacheable' => true,
    ),
    'html5player/hls_buffer_duration/16901113/2/513/index' => 
    array (
      'content_type' => 'application/json',
      'cacheable' => true,
    ),
    'html5player/hls_buffer_duration/16901113/2/140/index' => 
    array (
      'content_type' => 'application/json',
      'cacheable' => true,
    ),
    'o__static-hw.xvideos.com/v-2f5967de26b/v3/css/xnxx/front.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'o__static-hw.xvideos.com/v-3dfc41417f3/v3/js/skins/min/xnxx.header.static.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'o__static-hw.xvideos.com/v3/img/skins/xnxx/logo-xnxx.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'o__static-hw.xvideos.com/v3/js/libs/jquery.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'o__static-hw.xvideos.com/v-ae498561790/v3/js/skins/min/xnxx.footer.static.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'o__static-hw.xvideos.com/v3/js/skins/min/require.static.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'o__static-hw.xvideos.com/v-2f5967de26b/v3/img/skins/xnxx/top-stripe.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'o__static-hw.xvideos.com/v-00000000004/v3/img/skins/xnxx/icons-sprite.svg' => 
    array (
      'content_type' => 'image/svg+xml',
      'cacheable' => true,
    ),
    'o__static-hw.xvideos.com/v-2f5967de26b/v3/img/flags/flat/flags-32.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'o__static-hw.xvideos.com/v-2f5967de26b/v3/css/xnxx/front.css.map' => 
    array (
      'content_type' => 'application/octet-stream',
      'cacheable' => true,
    ),
    'o__static-hw.xvideos.com/v-588cfb9ce39/v3/css/player/html5.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'o__static-hw.xvideos.com/v-05513e9c717/v3/js/libs/hls.min.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'o__static-hw.xvideos.com/v3/js/i18n/xvplayer/english.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'o__static-hw.xvideos.com/v-05513e9c717/v3/js/skins/min/player.html5.static.js' => 
    array (
      'content_type' => 'application/javascript',
      'cacheable' => true,
    ),
    'html5player/hls_buffer_duration/16901113/2/728/index' => 
    array (
      'content_type' => 'application/json',
      'cacheable' => true,
    ),
    'html5player/hls_buffer_duration/16901113/2/270/index' => 
    array (
      'content_type' => 'application/json',
      'cacheable' => true,
    ),
    'o__static-hw.xvideos.com/v-588cfb9ce39/v3/css/player/html5.css.map' => 
    array (
      'content_type' => 'application/octet-stream',
      'cacheable' => true,
    ),
    'html5player/hls_loaded/15709751/2/index' => 
    array (
      'content_type' => 'application/json',
      'cacheable' => true,
    ),
    'html5player/hls_buffer_duration/15709751/2/1002/index' => 
    array (
      'content_type' => 'application/json',
      'cacheable' => true,
    ),
    'html5player/hls_playing/15709751/2/index' => 
    array (
      'content_type' => 'application/json',
      'cacheable' => true,
    ),
    'html5player/hls_buffer_duration/15709751/2/287/index' => 
    array (
      'content_type' => 'application/json',
      'cacheable' => true,
    ),
    'html5player/play_duration/15709751/2/7/index' => 
    array (
      'content_type' => 'application/json',
      'cacheable' => true,
    ),
    'css/layers.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'css/main.3003.min.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'css/map.min.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'css/maingreen.min.css' => 
    array (
      'content_type' => 'text/css',
      'cacheable' => true,
    ),
    'js/jquery.min.js' => 
    array (
      'content_type' => 'text/javascript',
      'cacheable' => true,
    ),
    'js/prototype.1.7.3.js' => 
    array (
      'content_type' => 'text/javascript',
      'cacheable' => true,
    ),
    'js/main.min.js' => 
    array (
      'content_type' => 'text/javascript',
      'cacheable' => true,
    ),
    'img/head/home.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/_n.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/head/acc.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/head/reg.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/head/map.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/head/rss.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/main/sp-soft-3.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/green/bgmain.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'img/green/color.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/main/bgo.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/green/main/bgr.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/green/menu/bg.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'advert/img/Decor.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'img/main/progh.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/icons/android.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/icons/ios.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/green/arrow.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/green/main/angler.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/main/bgprogs.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/green/head/hbg2.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/main/bgtitle.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/green/head/logo.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'img/green/main/bgrt.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/main/progw.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/green/left/bgtitle.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/green/main/bgr2.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'scr/43650/day-one-tmb-1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'img/arrow1.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/main/rsstitle.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/arrow3.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/green/menu/div.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/head/srch.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/menu/mobile2.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/menu/dev.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/menu/stat.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/green/head/hbg.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/green/head/h1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'img/sp-updater-wp.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'img/sp-updater-and.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'img/green/menu/bg-this.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/main/progm.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/main/progd.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/templates/_star4.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/main/newver.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'scr/39565/twitch-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'img/head/btn.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'img/sp_ny.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/menu/news.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/menu/progs.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/dot.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/templates/_star5.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'scr/37832/world-of-tanks-blitz-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/41539/firefox-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/39509/blablacar-poisk-poputchikov-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'img/templates/_star3.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/icons/win.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'scr/44687/makesoft-duplicatefinder-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/43158/camscanner-tmb-1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'scr/44537/angry-birds-match-tmb-1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'scr/20709/waze-community-gps-navigation-tmb-1.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'scr/39048/laya-music-player-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/38943/weather-underground-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/37481/avira-mobile-security-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/42228/rotate-video-fx-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/37133/google-tablitsi-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/13304/es-provodnik-tmb-5.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/42212/reverse-movie-fx-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/24571/yandeksnavigator-tmb-1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'scr/41740/kamera-z-tmb-1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'img/arrow4.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/draugda.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/main/news.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'news/icons/icon_27969.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'img/arrow2.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/main/och.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/vkontakte.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'img/main/clock.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'news/icons/icon_27968.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'news/icons/icon_27967.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'news/icons/icon_27966.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'news/icons/icon_27965.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'news/icons/icon_27964.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'news/icons/icon_27963.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'news/icons/icon_27962.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'news/icons/icon_27960.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'news/icons/icon_27959.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'img/main/clock2.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/main/newprog.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'scr/44706/avl-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'img/templates/_star0.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'scr/44705/video-download-capture-tmb-1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'scr/44704/kaspersky-anti-ransomware-tool-for-business-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/44702/tunnelbear-vpn-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/44701/kaspersky-total-security-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/44700/fps-monitor-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/44699/zemana-antivirus-security-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/44698/lim-multfilm-tv-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/44697/signal-private-messenger-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/43835/generator-loto-5-iz-36-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/44696/videoshow-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/44695/science-journal-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/44694/logdog-tmb-1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'scr/44693/dj-music-mixer-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/44689/itools-tmb-1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'scr/44688/tochkadokumentitsenniki-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/44686/logdog-mobilnaya-bezopasnost-tmb-1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'scr/44685/norton-mobile-security-tmb-1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'img/arrow5.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/love_softportal_rus.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'img/bottom/bg.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/yandex.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'img/photodoc.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/punto.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'img/driver.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'img/opera.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/19429/database-net-tmb-1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'scr/38119/log-viewer-plus-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'img/bshow.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/pic1.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/main/look2.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/update.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/hearth.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'img/cart.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/main/bg1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'scr/39335/decision-tree-with-time-limit-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'img/antivirus.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'img/winspy.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/2715/database-tour-tmb-1.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'scr/2878/emeditor-pro-tmb-1.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'scr/41566/uestudio-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/37913/android-studio-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/17272/ripexe-tmb-1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'scr/1171/nullsoft-scriptable-install-system-tmb-1.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'scr/448/ultraedit-32-tmb-1.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'scr/38848/cameyo-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/10173/dbforge-studio-dlya-mysql-tmb-1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'scr/24049/helpndoc-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/5359/free-hex-editor-tmb-1.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'scr/44648/phpstorm-tmb-2.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'img/yandex_200.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'img/arrow6.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'scr/9521/pascalabcnet-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'img/arrowr.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'scr/19138/java-runtime-environment-tmb-1.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'scr/16133/microsoft-net-framework-tmb-5.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'img/arrowl.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'scr/28236/pereimenovanie-fajlov-na-translit-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/44415/devesar-book-editor-tmb-9.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/43592/atom-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/38309/unity-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/40955/sublime-text-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/313/editpad-pro-tmb-1.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'scr/5647/createinstall-light-tmb-1.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'scr/2628/createinstall-tmb-1.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'scr/14381/chm-editor-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/41981/reportizer-viewer-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'scr/4134/reportizer-tmb-1.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'scr/31465/vrode-script-editor-tmb-1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'js/scriptaculous.1.9.0/scriptaculous.js_m_load=effects.js' => 
    array (
      'content_type' => 'text/javascript',
      'cacheable' => true,
    ),
    'js/quick_login.js' => 
    array (
      'content_type' => 'text/javascript',
      'cacheable' => true,
    ),
    'js/news_calendar.js' => 
    array (
      'content_type' => 'text/javascript',
      'cacheable' => true,
    ),
    'img/btoday.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/arrowl3.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'news/icons/icon_27961.jpeg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'news/icons/icon_27958.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'news/icons/icon_27957.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'news/icons/icon_27956.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'news/icons/icon_27955.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'img/loading.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'js/news_resp_rating.js' => 
    array (
      'content_type' => 'text/javascript',
      'cacheable' => true,
    ),
    'img/main/menu2/print.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/main/grey.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/main/menu2/bg1.png' => 
    array (
      'content_type' => 'image/png',
      'cacheable' => true,
    ),
    'img/main/menu2/comments.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/main/menu2/desc.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/main/dot.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'news/Image/2017/11/09/screen-shot-2017-11-02-at-2_37_56-pm-100741025-large.jpg' => 
    array (
      'content_type' => 'image/jpeg',
      'cacheable' => true,
    ),
    'img/main/fb.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'img/main/bg2.gif' => 
    array (
      'content_type' => 'image/gif',
      'cacheable' => true,
    ),
    'search_plugin.xml' => 
    array (
      'content_type' => 'text/xml',
      'cacheable' => true,
    ),
  ),
  'keys' => 
  array (
  ),
);
?>